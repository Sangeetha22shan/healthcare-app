package com.example.healthcareapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
