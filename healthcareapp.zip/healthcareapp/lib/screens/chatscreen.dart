import 'package:flutter/material.dart';
import 'package:healthcareapp/color.dart';
import 'package:healthcareapp/color.dart';
import 'package:healthcareapp/chatsamples.dart';
import 'package:cupertino_icons/cupertino_icons.dart';

class ChatScreen extends StatelessWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(70.0),
        child: AppBar(
          backgroundColor: primaryColor,
          leadingWidth: 30,
          title: Row(
            children: [
              CircleAvatar(
                radius: 25,
                backgroundImage: AssetImage("images/doctor1.jpg"),
              ),
              Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  "Dr. Doctor Name",
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
            ],
          ),
          actions: [
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.phone),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.video_call),
            ),
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Icon(Icons.more_vert),
            )
          ],
        ),
      ),
      body: ListView(
        padding: EdgeInsets.only(top: 20, left: 15, bottom: 80, right: 15),
        children: [
          ChatSample(),
          ChatSample(),
          ChatSample(),
          ChatSample(),
          ChatSample(),
          ChatSample(),
          ChatSample()
        ],
      ),
      bottomSheet: Container(
        height: 65,
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 2,
              blurRadius: 10,
            ),
          ],
        ),
        child: Row(
          children: [
            Padding(
              padding: EdgeInsets.only(left: 3.0),
              child: Icon(
                Icons.add,
                size: 25,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(left: 3.0),
              child: Icon(
                Icons.emoji_emotions_outlined,
                color: Colors.amber,
                size: 25,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(left: 10.0),
              child: Container(
                alignment: Alignment.centerRight,
                width: 270,
                child: TextFormField(
                  decoration: InputDecoration(
                      hintText: "Type Something", border: InputBorder.none),
                ),
              ),
            ),
            Spacer(),
            Padding(
              padding: EdgeInsets.only(right: 5.0),
              child: Icon(
                Icons.send,
                size: 30,
                color: primaryColor,
              ),
            )
          ],
        ),
      ),
    );
  }
}
