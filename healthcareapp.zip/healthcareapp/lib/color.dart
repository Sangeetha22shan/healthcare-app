import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF7165D6);
